Практическая работа по TypeScript.
