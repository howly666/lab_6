Лабораторная работа по TypeScript.
